# AndroidCalculadora
Calculadora android SIMPLE con base Kotlin

Calculadora simple para la clase de diseño de interfaces con código kotlin en Android
https://kotlinlang.org/

# Caracteristicas
*Operaciones simples (Suma, resta, multiplicación, etc)

*Operaciones con variables (Guardado, borrado, Mostrado)

*Operaciones con binarios (conversión, suma, etc)

*Borrado total y parcial de display

*Guardado de estado al cambiar de posición
